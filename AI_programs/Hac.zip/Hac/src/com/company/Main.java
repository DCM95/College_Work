package com.company;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) throws FileNotFoundException {
        final float CLUSTER_DISTANCE = (float) .105;
        File text = new File("src/com/company/B.txt");
        Scanner in = new Scanner(text);
        ArrayList<Node> nodeList = new ArrayList<Node>();
        while (in.hasNextLine()) {
            float x = in.nextFloat();
            float y = in.nextFloat();
            Node listNode = new Node(x, y);
            nodeList.add(listNode);
        }
        ArrayList<Cluster> cList = new ArrayList<Cluster>();
        for (int i = 0; i < nodeList.size(); i++) {
            Cluster cAdd = new Cluster(nodeList.get(i));
            cList.add(cAdd);
        }
        boolean check = true;
        //greatest distance before we stop grouping nodes into clusters
        float compDist = (float) 10000;
        while(check){
       // while (cList.size() > 2) {
            //high number to compare to
            float minDist = 10000;
            Cluster minC1 = new Cluster();
            Cluster minC2 = new Cluster();
            Cluster comp1 = new Cluster();
            Cluster comp2 = new Cluster();
            for (int i = 0; i < cList.size(); i++) {
                comp1 = cList.get(i);
                for (int j = i + 1; j < cList.size(); j++) {
                    comp2 = cList.get(j);
                    compDist = comp1.distance(comp2);
                    if (compDist < minDist) {
                        minDist = compDist;
                        minC1 = comp1;
                        minC2 = comp2;
                    }
                }
            }
            if (minC1 != null && minC2 != null) {
                minC1.addCluster(minC2);
                cList.remove(minC2);
            }
            if (minDist >= CLUSTER_DISTANCE) {
                check = false;
            }
        }
        StdDraw.setCanvasSize(1000, 1000);
        StdDraw.setXscale(0, 2);
        StdDraw.setYscale(0, 2);
        StdDraw.setPenRadius(.0100);
        //StdDraw.setPenColor(StdDraw.MAGENTA);
        int count = 0;
        while (count < cList.size()){
            int color1 = 0;
            int color2 = 0;
            int color3 = 0;
            if (count < 3) {
                 color1 = (150 +(count+1)*75)%255;
                 color2 = (150 +(count* 50)%255);
                 color3 = 0;
            } else
            if (count <7) {
                 color1 = 0;
                 color2 = (150 +(count+1)*75)%255;
                 color3 = (150 +(count * 50)%255);
            }else{
                 color1 = (count*15)%255;
                 color2 = (count*55)%255;
                 color3 = (count*35)%255;
            }


            StdDraw.setPenColor(color1, color2,color3);
            for (int i = 0; i < cList.get(count).nodes.size(); i++) {
                StdDraw.point(cList.get(count).nodes.get(i).getX(), cList.get(count).nodes.get(i).getY());
            }
//            StdDraw.setPenColor(StdDraw.GREEN);
//            for (int i = 0; i < cList.get(1).nodes.size(); i++) {
//                StdDraw.point(cList.get(1).nodes.get(i).getX(), cList.get(1).nodes.get(i).getY());
//            }
            count++;
        }
    }

}
class Cluster{
    public ArrayList<Node> nodes = new ArrayList<Node>();
    public Cluster(Node n){
        nodes.add(n);
    }
    public Cluster(){

    }
    public void addCluster(Cluster c){
        for (int i = 0; i<c.nodes.size(); i++){
            this.nodes.add(c.nodes.get(i));
        }
    }
    public float distance(Cluster c){
        float out = 0;
        float minDist = 10000;
        for (int i = 0;i<nodes.size();i++){
            for (int j = 0; j < c.nodes.size();j++){
                minDist = Math.min(nodes.get(i).distance(c.nodes.get(j)), minDist);
            }
        }
        out = minDist;
        return out;
    }
}

class Node{
    private float x, y;
    public Node(float xIn, float yIn){
        x = xIn;
        y = yIn;
    }

    //getters
    public float getX(){
        return x;
    }
    public float getY(){
        return y;
    }
    //to string
    public String toString(){
        return "x: " + x + "\ny: " + y;
    }
    public float distance(Node n){
        return (float) Math.round(Math.sqrt(Math.abs(Math.pow((n.getX() - this.x), 2) + Math.pow((n.getY() - this.y), 2)))*10000.0)/(float)10000;
    }

}