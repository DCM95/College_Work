package com.company;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class K_Means {

    public static void main(String[] args) throws FileNotFoundException {
        File text = new File("src/com/company/A.txt");
        Scanner in = new Scanner(text);
        ArrayList<Node> nodeList = new ArrayList<Node>();

        //read in and instantiate nodes
        while (in.hasNextLine()){
            float x = in.nextFloat();
            float y = in.nextFloat();
            Node listNode = new Node(x, y);
            nodeList.add(listNode);
        }
        //get random starting places for each center. using 2 because values of nodes range from 0 to 2
        Random rd = new Random();
        float randX = rd.nextFloat() * 2;
        float randY = rd.nextFloat() * 2;
        Center c1 = new Center(randX,randY,"c1");
        randX = rd.nextFloat() * 2;
        randY = rd.nextFloat() * 2;
        Center c2 = new Center(randX,randY,"c2");
        randX = rd.nextFloat() * 2;
        randY = rd.nextFloat() * 2;
        Center c3 = new Center(randX,randY,"c3");
        // keep track of if the centers move at all.
        int change = -1;


        while (change != 0) {
            //keep track of each center's average location and number of nodes belonging to it.
            float totalXDist1 = 0;
            float totalYDist1 = 0;
            float count1 = 0;
            float totalXDist2 = 0;
            float totalYDist2 = 0;
            float count2 = 0;
            float totalXDist3 = 0;
            float totalYDist3 = 0;
            float count3 = 0;
            // iterate through list and assign each point a center
            for (int i = 0; i < nodeList.size(); i++) {
                float c1Dist, c2Dist, c3Dist = 0;
                c1Dist = distance(nodeList.get(i).getX(), nodeList.get(i).getY(),c1.getX(), c1.getY());
                c2Dist = distance(nodeList.get(i).getX(), nodeList.get(i).getY(),c2.getX(), c2.getY());
                c3Dist = distance(nodeList.get(i).getX(), nodeList.get(i).getY(),c3.getX(), c3.getY());
                //compare all 3 distances
                if (Math.min(Math.min(c1Dist,c2Dist),c3Dist)==c1Dist){
                    count1++;
                    totalXDist1 += Math.abs(nodeList.get(i).getX());
                    totalYDist1 += Math.abs(nodeList.get(i).getY());
                    nodeList.get(i).setCenter(c1);
                } else
                if (Math.min(Math.min(c1Dist,c2Dist),c3Dist)==c2Dist){
                    count2++;
                    totalXDist2 += Math.abs(nodeList.get(i).getX());
                    totalYDist2 += Math.abs(nodeList.get(i).getY());
                    nodeList.get(i).setCenter(c2);
                } else
                if (Math.min(Math.min(c1Dist,c2Dist),c3Dist)==c3Dist){
                    count3++;
                    totalXDist3 += Math.abs(nodeList.get(i).getX());
                    totalYDist3 += Math.abs(nodeList.get(i).getY());
                    nodeList.get(i).setCenter(c3);
                }
                totalXDist1 = Math.round(totalXDist1*10000.0)/(float)10000;
                totalXDist2 = Math.round(totalXDist2*10000.0)/(float)10000;
                totalXDist3 = Math.round(totalXDist3*10000.0)/(float)10000;
                totalYDist1 = Math.round(totalYDist1*10000.0)/(float)10000;
                totalYDist2 = Math.round(totalYDist2*10000.0)/(float)10000;
                totalYDist3 = Math.round(totalYDist3*10000.0)/(float)10000;
            }
            //set the new coordinates for c1 c2 and c3. if they don't change, set change to 0
            boolean check = true;
            if (count1 != 0) {
                check = c1.setX((Math.round((totalXDist1 / count1)*10000.0))/(float)10000) && check;
                check = c1.setY((Math.round((totalYDist1 / count1)*10000.0))/(float)10000) && check;
            }
            if (count2 != 0) {
                check = c2.setX((Math.round((totalXDist2 / count2)*10000.0))/(float)10000) && check;
                check = c2.setY((Math.round((totalYDist2 / count2)*10000.0))/(float)10000) && check;
            }
            if (count3 != 0) {
                check = c3.setX((Math.round((totalXDist3 / count3)*10000.0))/(float)10000) && check;
                check = c3.setY((Math.round((totalYDist3 / count3)*10000.0))/(float)10000) && check;
            }
            if (check){
                        change = 0;
            }
        }
        //calculate distortion and output it
        float distortionReport;
        float c1Distort=0;
        float c2Distort=0;
        float c3Distort=0;
        for (int i = 0;i < nodeList.size();i++){
            if (nodeList.get(i).getCenter() == c1){
                c1Distort += Math.pow(distance(nodeList.get(i).getX(), nodeList.get(i).getY(),c1.getX(), c1.getY()), 2);
            }
            if (nodeList.get(i).getCenter() == c2){
                c2Distort += Math.pow(distance(nodeList.get(i).getX(), nodeList.get(i).getY(),c2.getX(), c2.getY()), 2);
            }
            if (nodeList.get(i).getCenter() == c3) {
                c3Distort += Math.pow(distance(nodeList.get(i).getX(), nodeList.get(i).getY(), c3.getX(), c3.getY()), 2);
            }
        }
        distortionReport = c1Distort + c2Distort + c3Distort;
        System.out.println("Distortion: " + distortionReport);

        //draw the plot
        StdDraw.setCanvasSize(1000,1000);
        StdDraw.setXscale(0,2);
        StdDraw.setYscale(0,2);
        StdDraw.setPenRadius(.0050);
        for (int i = 0;i < nodeList.size();i++){
            if (nodeList.get(i).getCenter() == c1){
                StdDraw.setPenColor(StdDraw.BOOK_LIGHT_BLUE);
                StdDraw.point(nodeList.get(i).getX(),nodeList.get(i).getY());
            }
            if (nodeList.get(i).getCenter() == c2){
                StdDraw.setPenColor(StdDraw.BOOK_RED);
                StdDraw.point(nodeList.get(i).getX(),nodeList.get(i).getY());
            }
            if (nodeList.get(i).getCenter() == c3) {
                StdDraw.setPenColor(StdDraw.LIGHT_GRAY);
                StdDraw.point(nodeList.get(i).getX(),nodeList.get(i).getY());
            }
        }
        StdDraw.setPenRadius(.0150);
        StdDraw.setPenColor(StdDraw.BOOK_BLUE);
        StdDraw.point(c1.getX(),c1.getY());
        StdDraw.setPenColor(StdDraw.RED);
        StdDraw.point(c2.getX(),c2.getY());
        StdDraw.setPenColor(StdDraw.DARK_GRAY);
        StdDraw.point(c3.getX(),c3.getY());
        StdDraw.save("plot1.png");
    }
    //distance formula
    static public float distance(float x1, float y1, float x2, float y2){
        return (float) Math.round(Math.sqrt(Math.abs(Math.pow((x1 - x2), 2) + Math.pow((y1 - y2), 2)))*10000.0)/(float)10000;
    }

}

class Node{
    private float x, y;
    private Center center;
    public Node(float xIn, float yIn){
        x = xIn;
        y = yIn;
    }

    //getters
    public float getX(){
        return x;
    }
    public float getY(){
        return y;
    }
    public Center getCenter(){
        return center;
    }
    //setting center
    public void setCenter(Center centerIn){
        center = centerIn;
    }
    //to string
    public String toString(){
        return "x: " + x + "\ny: " + y + "\nc: " + center.getLabel();
    }

}
class Center implements Comparable<Center>{
    private float x, y;
    private String label;

    public Center(float xIn, float yIn, String labelIn){
        x = xIn;
        y = yIn;
        label = labelIn;
    }
    //setters
    public boolean setX(float xIn){
       if (this.x == xIn){
            return true;
        }
        else {
            this.x = xIn;
            return false;
        }
    }
    public boolean setY(float yIn){
        if (this.y == yIn){
            return true;
        }
        else {
            this.y = yIn;
            return false;
        }
    }
    public void setLabel(String labelIn){
        label = labelIn;
    }
    //getters
    public float getX(){
        return x;
    }
    public float getY(){
        return y;
    }
    public String getLabel(){
        return label;
    }

    //compare methods
    public int compareTo(Center otherCenter){
        if (this.x == otherCenter.getX() && this.y == otherCenter.getY()){
            return 0;
        }
        else return -1;
    }
    public boolean equals(Object o){
        if (this == o ){
            return true;
        }
        if (o == null || getClass() != o.getClass()){
            return false;
        }
        Center center = (Center) o;
        return this.x == center.getX() && this.y == center.getY();
    }
    //to string
    public String toString(){
        return "x: " + x + "\ny: " + y;
    }

}
